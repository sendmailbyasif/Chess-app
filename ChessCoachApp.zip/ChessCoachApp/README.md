# ChessCoachApp
Offline Chess.com-style chess app (starter project).
